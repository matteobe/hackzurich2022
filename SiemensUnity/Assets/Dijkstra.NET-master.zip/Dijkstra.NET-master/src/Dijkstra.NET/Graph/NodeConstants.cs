﻿using System;

namespace Dijkstra.NET.Graph
{
    internal class NodeConstants
    {
        public const int MaxSize = Int32.MaxValue / 4;
    }
}