﻿namespace Dijkstra.NET.ShortestPath
{
    public delegate void Edge(uint node, int cost);
}